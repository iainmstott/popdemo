.onAttach <- function(libname, pkgname){
packageStartupMessage(
"Welcome to popdemo! Use ?popdemo for an introduction.
Citation for popdemo is here: doi.org/10.1111/j.2041-210X.2012.00222.x
Development and legacy versions are here: github.org/iainmstott/popdemo."
)
}
