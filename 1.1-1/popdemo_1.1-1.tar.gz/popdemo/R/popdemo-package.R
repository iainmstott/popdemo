################################################################################
#' Provides tools for demographic modelling using projection matrices
#'
#' @description
#' \code{popdemo} provides a set of tools designed for modelling population 
#' demography using population projection matrix (PPM) models. Specific foci are 
#' indices of transient dynamics, and the use of control theory.  However, 
#' \code{popdemo} may also be useful for other implementations of MPMs, 
#' or matrix models in a more general sense. \cr\cr
#' The package is designed to build on those tools already available in 
#' \code{popbio}.\cr\cr
#' Selected functions (see bottom of page for a link to the full index):\cr\cr
#' Functions useful for working with matrices:\cr
#' \code{popdemo} contains a number of tools to ease working with matrices
#' (and specifically PPMs) in \R.
#' \code{\link{Matlab2R}} allows coding of matrices in a Matlab style, which
#' also facilitates import of multiple matrices simultaneously if comma-seperated
#' files are used to import dataframes.  Its analogue, \code{\link{R2Matlab}},
#' converts \R matrices to Matlab-style strings, for easier export.\cr
#' \code{\link{isPrimitive}}, \code{\link{isIrreducible}} and
#' \code{\link{isErgodic}} facilitate diagnosis of matrix properties
#' pertaining to ergodicity.\cr\cr
#' Population projection:\cr
#' \code{popdemo} provides a simple means of projecting and plotting PPM models.
#' \code{\link{project}} will project population dynamics and a plotting method
#' is available via \code{\link{plot.projection}}.\cr\cr
#' Indices of transient density:\cr
#' Transient dynamics are important to study in PPM models, and \code{popdemo}
#' provides the means to work with transient indices of PPM models.
#' \code{\link{reac}} measures immediate transient density of a population 
#' (within the first time step). 
#' \code{\link{maxamp}} and \code{\link{maxatt}} are near-term indices that 
#' measure the largest and smallest transient dynamics a population may exhibit 
#' overall.  
#' \code{\link{inertia}} measures asymptotic population density relative to stable
#' state, and has many perturbation methods in the package (see below).  All indices
#' can be calculated using specific population structures, as well as bounds on
#' population size.\cr\cr
#' Perturbation analysis:\cr
#' Perturbation analysis is a key part of population studies. \code{popdemo} provides
#' methods for nonlinear perturbation analysis of both asymptotic dynamics, using \code{\link{tfa_lambda}} and
#' \code{\link{tfam_lambda}}, and transient dynamics, using \code{\link{tfa_inertia}} and
#' \code{\link{tfam_inertia}}.  These all have associated plotting methods linked to them: see
#' \code{\link{plot.tfa}} and \code{\link{plot.tfam}}).  Sensitivity analyses are also available
#' using transfer function methods: see \code{\link{tfs_lambda}}, \code{\link{tfsm_lambda}}, 
#' \code{\link{tfs_inertia}} and \code{\link{tfsm_inertia}}.  (Traditional perturbation
#' analyses are also available: \code{\link{sens}}, \code{\link{elas}}).\cr\cr
#' Indices of convergence:\cr
#' Information on the convergence of populations to stable state can be useful, and
#' \code{popdemo} provides several means of analysing convergence.
#' \code{dr} measures the damping ratio, and there are several distance measures available
#' (see \code{\link{KeyfitzD}}, \code{\link{projectionD}} and 
#' \code{\link{CohenD}}).  There is also a means of calculating convergence time
#' through simulation: \code{\link{convt}}.\cr
#'
"_PACKAGE"
