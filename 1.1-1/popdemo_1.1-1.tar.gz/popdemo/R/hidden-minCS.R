.minCS <-
function(A){
add<-colSums(A)
return(min(add))
}
